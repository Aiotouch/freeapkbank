<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Resource;

class PagesController extends Controller
{
    

    public function index()
    {

        $resources = Resource::get();

        return view("index")->with([
            "resources" => $resources
        ]);

    }



    public function mobile()
    {

        $resources = Resource::where("category", "android")
                                                    ->orWhere("category", "ios")
                                                    ->get();

        return view("index")->with([
            "resources" => $resources
        ]);

    }



    public function pc()
    {

        $resources = Resource::where("category", "windows")
                                                    ->orWhere("category", "macos")
                                                    ->orWhere("category", "linux")
                                                    ->get();

        return view("index")->with([
            "resources" => $resources
        ]);

    }



    public function tutorials()
    {

        $resources = Resource::where("category", "programming")
                                                    ->orWhere("category", "graphics")
                                                    ->orWhere("category", "hacking")
                                                    ->orWhere("category", "carding")
                                                    ->get();

        return view("index")->with([
            "resources" => $resources
        ]);

    }






    // <=========== CATEGORIES SECTION =============>

    public function android()
    {

        $resources = Resource::get()->where("category", "android");

        return view("index")->with([
            "resources" => $resources
        ]);
    }


    public function ios()
    {

        $resources = Resource::get()->where("category", "ios");

        return view("index")->with([
            "resources" => $resources
        ]);
    }


    public function windows()
    {

        $resources = Resource::get()->where("category", "windows");

        return view("index")->with([
            "resources" => $resources
        ]);
    }


    public function macos()
    {

        $resources = Resource::get()->where("category", "macos");

        return view("index")->with([
            "resources" => $resources
        ]);
    }


    public function linux()
    {

        $resources = Resource::get()->where("category", "linux");

        return view("index")->with([
            "resources" => $resources
        ]);
    }





    // <============= MAIN ROUTES ========>

    public function programming()
    {

        $resources = Resource::get()->where("category", "programming");

        return view("index")->with([
            "resources" => $resources
        ]);
    }


    public function graphics()
    {

        $resources = Resource::get()->where("category", "graphics");

        return view("index")->with([
            "resources" => $resources
        ]);
    }


    public function hacking()
    {

        $resources = Resource::get()->where("category", "hacking");

        return view("index")->with([
            "resources" => $resources
        ]);
    }


    public function carding()
    {

        $resources = Resource::get()->where("category", "carding");

        return view("index")->with([
            "resources" => $resources
        ]);
    }


}
