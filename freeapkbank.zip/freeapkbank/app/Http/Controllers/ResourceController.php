<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Resource;

class ResourceController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $resources = Resource::get();
        
        return view("admin.dashboard")->with([
            "resources" => $resources
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        

        return view("admin.create-resource");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        // $request->validate([
        //     "resource_name" => ['required'],
        //     "category" => ['required'],
        //     "image_path" => ['required', 'mimes:png,jpg,jpeg'],
        //     "file_path" => ['required']
        // ]);


        $downloads = 0;
        $newImageName = "";

        if (isset($request->image_path)){
            
            $newImageName = time() .  '-' . $request->name . '.' . $request->image_path->extension();

            $request->file('image_path')->storePubliclyAs('public/resource_images', $newImageName);
        }

        $resource = Resource::create([
            'resource_name' => $request->name,
            'category' => $request->category,
            'image_path' => $newImageName,
            'file_path' => $request->file_path,
            'downloads' => $downloads
        ]);


            return redirect()->route("admin-dashboard")->with([
                "alert_message" => "New resource uploaded succesfully!"
            ]);
        

    }

    // /**
    //  * Display the specified resource.
    //  *
    //  * @param  int  $id
    //  * @return \Illuminate\Http\Response
    //  */
    
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $resource = Resource::find($id);

        return view("admin.edit-resource")->with([
            "resource" => $resource
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        Resource::find($id)->update([
            "resource_name" => $request->name,
            "category" => $request->category,
            "image_path" => $request->image_path,
            "file_path" => $request->file_path
        ]);


        return redirect()->route("admin-dashboard");

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        
        Resource::find($id)->delete();

        return redirect()->route("admin-dashboard");

    }
}