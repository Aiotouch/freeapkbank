<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Resource extends Model
{
    use HasFactory;

    protected $tableName = "resources";

    protected $primaryKey = "id";

    protected $fillable = ['resource_name', 'category', 'image_path', 'file_path', 'downloads'];


}
