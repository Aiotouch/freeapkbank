<!doctype html>
<html lang="">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin Dashboard | Freeapkbank</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('/front/js/bootstrap.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset("/front/css/bootstrap.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("/front/css/bootstrap.min.css")); ?>">
</head>

<body>


    


    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>



    <script src="<?php echo e(asset("/front/js/jquery.js")); ?>"></script>
    <script src="<?php echo e(asset("/front/js/bootstrap.js")); ?>"></script>
    <script src="<?php echo e(asset("/front/js/bootstrap.bundle.min.js")); ?>"></script>
</body>

</html><?php /**PATH /opt/lampp/htdocs/freeapkbank/resources/views/layouts/main.blade.php ENDPATH**/ ?>