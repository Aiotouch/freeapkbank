<?php $__env->startSection("title"); ?>
<title>Freeapkbank | Home</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("content"); ?>

<section class="bg-secondary text-white">
    <div class="container p-2 shadow-sm">
        




        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                    aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                    aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                    aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <center>
                        <img src="<?php echo e(asset("/storage/carousel1.jpeg")); ?>" class="d-block w-50 carousel-image" alt="...">
                    </center>
                    <div class="carousel-caption d-none d-md-block text-dark">
                        <h5>Mobile Apps</h5>
                        <p>We provide hacked Android/iOS apps for <span class="lead fs-bold">free</span></p>
                    </div>
                </div>
                <div class="carousel-item">
                    <center>
                        <img src="<?php echo e(asset("/storage/carousel2.jpeg")); ?>" class="d-block w-auto" alt="...">
                    </center>
                    <div class="carousel-caption d-none d-md-block text-dark">
                        <h5>Desktop Apps</h5>
                        <p>We provide hacked destop apps for <span class="lead fw-bold">free</span></p>
                    </div>
                </div>
                <div class="carousel-item">
                    <center>
                        <img src="<?php echo e(asset("/storage/carousel3.jpeg")); ?>" class="d-block w-80" alt="...">
                    </center>
                    <div class="carousel-caption d-none d-md-block text-dark">
                        <h5>Tutorials</h5>
                        <p>We provide tutorials for various categories also for <span class="lead fs-bold">free</span>
                        </p>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>




    </div>
</section>



<section>
    <div class="container mb-1 mt-1">
        Ads section
    </div>
</section>



<section class="bg-dark text-white mt-2">
    <div class="container pt-5">
        <div class="row">
            <div class="col-lg-8 shadow-sm p-4">

                <?php $__empty_1 = true; $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <div class="container p-2 shadow-sm p-3 d-flex align-items-center justify-content-between mt-2 mb-3">
                        
                        <div>
                            <h3><?php echo e($resource->resource_name); ?></h3>
                            <p class="mt-1"><?php echo e($resource->category); ?></p>
                        </div>
                        <a href="<?php echo e($resource->file_path); ?>" class="btn btn-success download-btn">
                            Download <i class="bi bi-download"></i>
                        </a>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    
                    <div class="container p-2 shadow-sm p-3 d-flex align-items-center justify-content-between mt-2 mb-3">
                        <p class="h3">No results found!</p>
                    </div>

                <?php endif; ?>

            </div>
            <div class="col-lg-4 shadow-sm p-3">
                <ul>
                    <h2 class="lead mb-3">Categories</h2>
                    <li class="lead mb-1"><a href="<?php echo e(route("home")); ?>">All</a></li>
                    <hr>
                    <h3 class="lead mb-2">Applications</h3>
                    <li class="mt-1 mb-1 list-item"><a href="<?php echo e(route("android")); ?>">Android</a></li>
                    <li class="mb-1 list-item"><a href="<?php echo e(route("ios")); ?>">iOS</a></li>
                    <li class="mb-1 list-item"><a href="<?php echo e(route("windows")); ?>">Windows</a></li>
                    <li class="mb-1 list-item"><a href="<?php echo e(route("macos")); ?>">macOS</a></li>
                    <li class="mb-1 list-item"><a href="<?php echo e(route("linux")); ?>">Linux</a></li>
                    <hr>
                    <h3 class="lead mb-2">Tutorials</h3>
                    <li class="mt-1 mb-1 list-item"><a href="<?php echo e(route("programming")); ?>">Programming</a></li>
                    <li class="mb-1 list-item"><a href="<?php echo e(route("graphics-design")); ?>">Graphics Design</a></li>
                    <li class="mb-1 list-item"><a href="<?php echo e(route("hacking")); ?>">Hacking</a></li>
                    <li class="mb-1 list-item"><a href="<?php echo e(route("carding")); ?>">Carding</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/freeapkbank/resources/views/index.blade.php ENDPATH**/ ?>