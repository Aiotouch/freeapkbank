<?php $__env->startSection("title"); ?>
    <title>Edit Resource | Freeapkbank Admin Panel</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

<section>
    <div class="container py-4">
        <center>
            <form action="<?php echo e(route("update-resource", $resource->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="name">Resource Name</label>
                    <input type="text" name="name" id="name" value="<?php echo e($resource->resource_name); ?>">
                </div>
                <div>
                    <label for="category">Category</label>
                    <input type="text" name="category" id="category" value="<?php echo e($resource->category); ?>">
                </div>
                <div>
                    <label for="image_path">Image Path</label>
                    <input type="file" name="image_path" id="image_path" value="<?php echo e($resource->image_path); ?>">
                </div>
                <div>
                    <label for="file_path">File Path</label>
                    <input type="text" name="file_path" id="file_path" value="<?php echo e($resource->file_path); ?>">
                </div>
                <button class="btn btn-primary" type="submit">Save Changes</button>
            </form>
        </center>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/freeapkbank/resources/views/admin/edit-resource.blade.php ENDPATH**/ ?>