<?php $__env->startSection("content"); ?>

<section>
    <div class="container p-5">

        <div class="container p-3 mb-5">
            <a href="<?php echo e(route("resource-create-page")); ?>" class="btn btn-outline-primary">Create New Resource &rarr;</a>
        </div>

        <table class="table table-hover table-light shadow-sm">
            <thead>
                <th>#</th>
                <th>Resource name</th>
                <th>Category</th>
                <th>Image Path</th>
                <th>File Path</th>
                <th>Downloads</th>
                <th>Created At</th>
                <th>Updated At</th>
                <th>Actions</th>
            </thead>

            <tbody>
                <?php echo e($id = 0); ?>

                <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e(++$id); ?></th>
                    <td><?php echo e($resource->resource_name); ?></td>
                    <td><?php echo e($resource->category); ?></td>
                    <td><?php echo e($resource->image_path); ?></td>
                    <td><?php echo e($resource->file_path); ?></td>
                    <td><?php echo e($resource->downloads); ?></td>
                    <td><?php echo e($resource->created_at); ?></td>
                    <td><?php echo e($resource->updated_at); ?></td>
                    <td>
                        <a href="<?php echo e(route("edit-resource", $resource->id)); ?>" class="btn btn-outline-primary">Edit</a>
                        <form action="<?php echo e(route("delete-resource", $resource->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-outline-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/freeapkbank/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>