<?php $__env->startSection("title"); ?>
    <title>Create A Resource | Freeapkbank Admin Panel</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

<section>

    <?php if(isset($_SESSION["alert_message"])): ?>

        <div class="container py-4">
            <p class="alert alert-success">
                <?php echo e($_SESSION["alert_message"]); ?>

            </p>
        </div>
    
    <?php elseif(isset($_SESSION["upload_error"])): ?>

        <div class="container py-4">
            <p class="alert alert-danger">
                <?php echo e($_SESSION["upload_error"]); ?>

            </p>
        </div>

    <?php endif; ?>

    <div class="container p-5">
        <a href="<?php echo e(route("admin-dashboard")); ?>" class="btn btn-outline-primary">&larr; Go back</a>
    </div>

    <div class="container p-4">
            <form class="p-5" action="<?php echo e(route("create-resource")); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-1">
                    <label for="name">Resource Name</label>
                    <input class="form-control mt-1" type="text" name="name" id="name">
                </div>
                <div class="form-group mb-1">
                    <label for="category">Category</label>
                    <input class="form-control mt-1" type="text" category="category" name="category" id="category">
                </div>
                <div class="form-group mb-1">
                    <label for="image_path">Image Path</label>
                    <input class="form-control-file mt-1"type="file" name="image_path" id="image_path">
                </div>
                <div class="form-group mb-1">
                    <label for="file_path">File Path</label>
                    <input class="form-control mt-1" type="text" name="file_path" id="file_path">
                </div>
                <button class="btn btn-primary mt-1" type="submit">Upload</button>
            </form>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/freeapkbank/resources/views/admin/create-resource.blade.php ENDPATH**/ ?>