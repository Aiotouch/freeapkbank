<?php $__env->startSection("title"); ?>
    <title>Freeapkbank | Home</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("content"); ?>
    
    <div class="container col-md-10">
        <p>This is the body iin index page</p>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aiotouch/Desktop/freeapkbank/freeapkbank/resources/views/index.blade.php ENDPATH**/ ?>