<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\PagesController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\ResourceController;
use SebastianBergmann\CodeCoverage\Report\Html\Dashboard;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



// Routes without middleware
Route::get('/', [PagesController::class, 'index'])->name("home");
Route::get('/mobile', [PagesController::class, 'mobile'])->name("mobile");
Route::get('/pc', [PagesController::class, 'pc'])->name("pc");
Route::get('/tutorials', [PagesController::class, 'tutorials'])->name("tutorials");
Route::get('/affiliate', [PagesController::class, 'affliate'])->name("affliliate");



// <============= ADMIN ROUTES ==============>

Route::get('/admin', [LoginController::class, 'index'])->name('login-page');
Route::get('/admin/register-page', [RegisterController::class, 'create'])->name("admin-register-page");
Route::get('/admin/dashboard', [ResourceController::class, 'index'])->middleware("auth")->name("admin-dashboard");
Route::get('/admin/resources/create-a-resource', [ResourceController::class, 'create'])->middleware("auth")->name("resource-create-page");
Route::get('/admin/resources/edit/{id}', [ResourceController::class, 'edit'])->middleware("auth")->name("edit-resource");


Route::post('/admin/login', [LoginController::class, 'store'])->name("login-admin");
Route::post('/admin/register', [RegisterController::class, 'store'])->name("register-admin");
Route::post('/admin/resources/create', [ResourceController::class, 'store'])->name("create-resource");
Route::post('/admin/resources/update/{id}', [ResourceController::class, 'update'])->name("update-resource");
Route::post('/admin/resource/delete/{id}', [ResourceController::class, 'destroy'])->name("delete-resource");




// <=========== CATEGORIES SECTION ================>

Route::get('/applications/android', [PagesController::class, 'android'])->name("android");
Route::get('/applications/ios', [PagesController::class, 'ios'])->name("ios");
Route::get('/applications/windows', [PagesController::class, 'windows'])->name("windows");
Route::get('/applications/macos', [PagesController::class, 'macos'])->name("macos");
Route::get('/applications/linux', [PagesController::class, 'linux'])->name("linux");



Route::get('/tutorials/programming', [PagesController::class, 'programming'])->name("programming");
Route::get('/tutorials/graphics-design', [PagesController::class, 'graphics-design'])->name("graphics-design");
Route::get('/tutorials/hacking', [PagesController::class, 'hacking'])->name("hacking");
Route::get('/tutorials/carding', [PagesController::class, 'carding'])->name("carding");