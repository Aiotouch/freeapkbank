@extends("layouts.app")


@section("title")
<title>Freeapkbank | Home</title>
@endsection


@section("content")

<section class="bg-secondary text-white">
    <div class="container p-2 shadow-sm">
        {{-- <div class="row">
                <div class="col-md-6 ms-auto">
                    <h3 class="lead fs-5">All of your cracked apps are available</h3>
                    <p class="">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                        Aperiam, voluptate, dolore sunt minus perferendis vitae velit commodi 
                        asperiores explicabo deserunt vel corrupti exercitationem porro nobis 
                        labore ullam neque architecto. Esse inventore quasi asperiores architecto 
                        expedita! Laborum officiis exercitationem nihil eaque dolor cumque sequi 
                        dicta, asperiores voluptas sunt corrupti. Totam, accusamus.
                    </p>
                </div>
                <div class="col-md-6">
                    
                </div>
            </div> --}}




        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                    aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                    aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                    aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <center>
                        <img src="{{ asset("/storage/carousel1.jpeg") }}" class="d-block w-50 carousel-image" alt="...">
                    </center>
                    <div class="carousel-caption d-none d-md-block text-dark">
                        <h5>Mobile Apps</h5>
                        <p>We provide hacked Android/iOS apps for <span class="lead fs-bold">free</span></p>
                    </div>
                </div>
                <div class="carousel-item">
                    <center>
                        <img src="{{ asset("/storage/carousel2.jpeg") }}" class="d-block w-auto" alt="...">
                    </center>
                    <div class="carousel-caption d-none d-md-block text-dark">
                        <h5>Desktop Apps</h5>
                        <p>We provide hacked destop apps for <span class="lead fw-bold">free</span></p>
                    </div>
                </div>
                <div class="carousel-item">
                    <center>
                        <img src="{{ asset("/storage/carousel3.jpeg") }}" class="d-block w-80" alt="...">
                    </center>
                    <div class="carousel-caption d-none d-md-block text-dark">
                        <h5>Tutorials</h5>
                        <p>We provide tutorials for various categories also for <span class="lead fs-bold">free</span>
                        </p>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>




    </div>
</section>



<section>
    <div class="container mb-1 mt-1">
        Ads section
    </div>
</section>



<section class="bg-dark text-white mt-2">
    <div class="container pt-5">
        <div class="row">
            <div class="col-lg-8 shadow-sm p-4">

                @forelse ($resources as $resource)

                    <div class="container p-2 shadow-sm p-3 d-flex align-items-center justify-content-between mt-2 mb-3">
                        {{-- <img style="width: 6rem;" src="{{ asset("/storage/resource_images/".$resource->image_path) }}" class="img-fluid" alt="image"> --}}
                        <div>
                            <h3>{{ $resource->resource_name }}</h3>
                            <p class="mt-1">{{ $resource->category }}</p>
                        </div>
                        <a href="{{ $resource->file_path }}" class="btn btn-success download-btn">
                            Download <i class="bi bi-download"></i>
                        </a>
                    </div>

                @empty
                    
                    <div class="container p-2 shadow-sm p-3 d-flex align-items-center justify-content-between mt-2 mb-3">
                        <p class="h3">No results found!</p>
                    </div>

                @endforelse

            </div>
            <div class="col-lg-4 shadow-sm p-3">
                <ul>
                    <h2 class="lead mb-3">Categories</h2>
                    <li class="lead mb-1"><a href="{{ route("home") }}">All</a></li>
                    <hr>
                    <h3 class="lead mb-2">Applications</h3>
                    <li class="mt-1 mb-1 list-item"><a href="{{ route("android") }}">Android</a></li>
                    <li class="mb-1 list-item"><a href="{{ route("ios") }}">iOS</a></li>
                    <li class="mb-1 list-item"><a href="{{ route("windows") }}">Windows</a></li>
                    <li class="mb-1 list-item"><a href="{{ route("macos") }}">macOS</a></li>
                    <li class="mb-1 list-item"><a href="{{ route("linux") }}">Linux</a></li>
                    <hr>
                    <h3 class="lead mb-2">Tutorials</h3>
                    <li class="mt-1 mb-1 list-item"><a href="{{ route("programming") }}">Programming</a></li>
                    <li class="mb-1 list-item"><a href="{{ route("graphics-design") }}">Graphics Design</a></li>
                    <li class="mb-1 list-item"><a href="{{ route("hacking") }}">Hacking</a></li>
                    <li class="mb-1 list-item"><a href="{{ route("carding") }}">Carding</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>

@endsection