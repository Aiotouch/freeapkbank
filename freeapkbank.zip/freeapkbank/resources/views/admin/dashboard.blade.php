@extends("layouts.main")

@section("content")

<section>
    <div class="container p-5">

        <div class="container p-3 mb-5">
            <a href="{{ route("resource-create-page") }}" class="btn btn-outline-primary">Create New Resource &rarr;</a>
        </div>

        <table class="table table-hover table-light shadow-sm">
            <thead>
                <th>#</th>
                <th>Resource name</th>
                <th>Category</th>
                <th>Image Path</th>
                <th>File Path</th>
                <th>Downloads</th>
                <th>Created At</th>
                <th>Updated At</th>
                <th>Actions</th>
            </thead>

            <tbody>
                {{ $id = 0; }}
                @foreach ($resources as $resource)
                <tr>
                    <th>{{ ++$id; }}</th>
                    <td>{{ $resource->resource_name }}</td>
                    <td>{{ $resource->category }}</td>
                    <td>{{ $resource->image_path }}</td>
                    <td>{{ $resource->file_path }}</td>
                    <td>{{ $resource->downloads }}</td>
                    <td>{{ $resource->created_at }}</td>
                    <td>{{ $resource->updated_at }}</td>
                    <td>
                        <a href="{{ route("edit-resource", $resource->id) }}" class="btn btn-outline-primary">Edit</a>
                        <form action="{{ route("delete-resource", $resource->id) }}" method="post">
                            @csrf
                            <button type="submit" class="btn btn-outline-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</section>

@endsection