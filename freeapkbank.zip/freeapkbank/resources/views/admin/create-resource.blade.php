@extends("layouts.main")

@section("title")
    <title>Create A Resource | Freeapkbank Admin Panel</title>
@endsection

@section("content")

<section>

    @if (isset($_SESSION["alert_message"]))

        <div class="container py-4">
            <p class="alert alert-success">
                {{ $_SESSION["alert_message"] }}
            </p>
        </div>
    
    @elseif (isset($_SESSION["upload_error"]))

        <div class="container py-4">
            <p class="alert alert-danger">
                {{ $_SESSION["upload_error"] }}
            </p>
        </div>

    @endif

    <div class="container p-5">
        <a href="{{ route("admin-dashboard") }}" class="btn btn-outline-primary">&larr; Go back</a>
    </div>

    <div class="container p-4">
            <form class="p-5" action="{{ route("create-resource") }}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="form-group mb-1">
                    <label for="name">Resource Name</label>
                    <input class="form-control mt-1" type="text" name="name" id="name">
                </div>
                <div class="form-group mb-1">
                    <label for="category">Category</label>
                    <input class="form-control mt-1" type="text" category="category" name="category" id="category">
                </div>
                <div class="form-group mb-1">
                    <label for="image_path">Image Path</label>
                    <input class="form-control-file mt-1"type="file" name="image_path" id="image_path">
                </div>
                <div class="form-group mb-1">
                    <label for="file_path">File Path</label>
                    <input class="form-control mt-1" type="text" name="file_path" id="file_path">
                </div>
                <button class="btn btn-primary mt-1" type="submit">Upload</button>
            </form>
    </div>
</section>

@endsection