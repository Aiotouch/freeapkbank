@extends("layouts.main")

@section("title")
    <title>Edit Resource | Freeapkbank Admin Panel</title>
@endsection

@section("content")

<section>
    <div class="container py-4">
        <center>
            <form action="{{ route("update-resource", $resource->id) }}" method="post" enctype="multipart/form-data">
                @csrf
                <div>
                    <label for="name">Resource Name</label>
                    <input type="text" name="name" id="name" value="{{ $resource->resource_name }}">
                </div>
                <div>
                    <label for="category">Category</label>
                    <input type="text" name="category" id="category" value="{{ $resource->category }}">
                </div>
                <div>
                    <label for="image_path">Image Path</label>
                    <input type="file" name="image_path" id="image_path" value="{{ $resource->image_path }}">
                </div>
                <div>
                    <label for="file_path">File Path</label>
                    <input type="text" name="file_path" id="file_path" value="{{ $resource->file_path }}">
                </div>
                <button class="btn btn-primary" type="submit">Save Changes</button>
            </form>
        </center>
    </div>
</section>

@endsection