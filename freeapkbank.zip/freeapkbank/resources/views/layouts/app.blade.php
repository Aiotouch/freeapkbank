<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    @yield("title")

    <link rel="stylesheet" href="{{ asset("/front/css/bootstrap.css") }}">
    <link rel="stylesheet" href="{{ asset("/front/css/bootstrap.min.css") }}">
    <link rel="stylesheet" href="{{ asset("/front/css/style.css") }}">
</head>

<body>


    <nav class="navbar navbar-expand-lg bg-primary navbar-dark shadow-sm fixed-top">
        <div class="container">
            <a href="{{ route("home") }}" class="navbar-brand text-uppercase text-light lead fs-4">Freeapkbank</a>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto p-2">
                    <li class="nav-item">
                        <a href="{{ route("home") }}" class="nav-link text-uppercase">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route("mobile") }}" class="nav-link text-uppercase">Mobile</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route("pc") }}" class="nav-link text-uppercase">PC</a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ route("tutorials") }}" class="nav-link text-uppercase">Tutorials</a>
                    </li>
                    {{-- <li class="nav-item">
                        <a href="{{ route("affliliate") }}" class="nav-link text-uppercase">Affliliate</a>
                    </li> --}}
                </ul>
            </div>
        </div>
    </nav>



    @yield("content")



    <footer class="bg-dark p-3">
        <div class="container mt-3 p-2 text-center text-light">
            <div class="text-light">
                <a href=""><i class="bi bi-facebook"></i></a>
                <a href=""><i class="bi bi-whatsapp"></i></a>
                <a href=""><i class="bi bi-instagram"></i></a>
                <a href=""><i class="bi bi-phone"></i></a>
            </div>
            <div class="mb-1">
                <a class="" href="">Designed by <span class="text-danger">Aiotouch Softwares</span></a>
            </div>
            <p>Copyright &copy; 2021 Freeapkbank.</p>
        </div>
    </footer>


    <script src="{{ asset("/front/js/jquery.js") }}"></script>
    <script src="{{ asset("/front/js/bootstrap.js") }}"></script>
    <script src="{{ asset("/front/js/bootstrap.bundle.min.js") }}"></script>
</body>

</html>