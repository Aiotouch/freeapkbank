<!doctype html>
<html lang="">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    @yield("title")

    <!-- Scripts -->
    <script src="{{ asset('/front/js/bootstrap.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="{{ asset("/front/css/bootstrap.css") }}">
    <link rel="stylesheet" href="{{ asset("/front/css/bootstrap.min.css") }}">
</head>

<body>


    {{-- <aside>
        <div class="container py-4">
            <ul class="list-group">
                <li class="list-group-item">

                </li>
            </ul>
        </div>
    </aside> --}}


    <main class="py-4">
        @yield('content')
    </main>



    <script src="{{ asset("/front/js/jquery.js") }}"></script>
    <script src="{{ asset("/front/js/bootstrap.js") }}"></script>
    <script src="{{ asset("/front/js/bootstrap.bundle.min.js") }}"></script>
</body>

</html>